#!/bin/bash

g++ -std=c++14 -O2 -march=native solver.cpp
