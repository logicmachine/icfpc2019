#!/bin/bash

./a.out $1
