class Effect {
  constructor(){
  }
}
