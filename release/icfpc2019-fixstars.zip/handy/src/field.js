class Field {
  constructor(canvas){
    this.canvas = canvas;
  }
}
