const CELL_OBSTACLE  = 0;
const CELL_EMPTY     = 1;
const CELL_WRAPPED   = 2;
const CELL_REACHING  = 3;
const CELL_NEW_MANIP = 4;
const CELL_FAST      = 5;
const CELL_DRILL     = 6;
const CELL_ROBOT     = 7;
