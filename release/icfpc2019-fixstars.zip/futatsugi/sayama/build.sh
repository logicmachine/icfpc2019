#!/bin/sh

#cd futatsugi/sayama
c++ solver_nf.cpp -O3 -std=c++14 -o solver_nf
