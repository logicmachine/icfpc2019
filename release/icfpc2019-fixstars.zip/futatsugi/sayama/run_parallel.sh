#!/bin/sh

./solver_nf_parallel ${1} ${2}
