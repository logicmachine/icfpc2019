#!/bin/sh

./solver_nf ${1}
