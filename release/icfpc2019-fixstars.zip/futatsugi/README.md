# Solution for futatsugi

## Build

In futatsugi/sayama:

```
$ ./build.sh
$ ./biuld_parallel.sh  # for clone workers
```

## Run solution

```
$ ./run.sh
$ ./run_parallel.sh  # for clone workers
```
